from dataclasses import dataclass
from difflib import SequenceMatcher
from math import isfinite
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Tuple, Union

from javalang.tokenizer import tokenize

from .adversarial import analyze_adversarial_resistance
from .languages import compare_token_signals, detect_language


FilePath = Union[str, Path]
TokenSequence = Tuple[str, ...]
TokenSpan = Tuple[int, int, int, int]


@dataclass(frozen=True)
class PlagiarismMatch:
    """A comparison between a source submission and a candidate file."""

    candidate: str
    similarity: float
    matched_tokens: int
    source_tokens: int
    candidate_tokens: int
    matching_blocks: Tuple[TokenSpan, ...]
    is_plagiarism: bool
    adversarial_similarity: float = 0.0
    residual_deviation: float = 1.0
    deviation_remains: bool = True
    resistance_value: float = 0.0

    def as_dict(self) -> Dict[str, object]:
        """Return a JSON-serializable representation of this match."""
        return {
            'candidate': self.candidate,
            'similarity': self.similarity,
            'matched_tokens': self.matched_tokens,
            'source_tokens': self.source_tokens,
            'candidate_tokens': self.candidate_tokens,
            'matching_blocks': [list(block) for block in self.matching_blocks],
            'is_plagiarism': self.is_plagiarism,
            'adversarial_similarity': self.adversarial_similarity,
            'residual_deviation': self.residual_deviation,
            'deviation_remains': self.deviation_remains,
            'resistance_value': self.resistance_value
        }


def _validate_threshold(threshold: float) -> None:
    if not isfinite(threshold) or not 0.0 <= threshold <= 1.0:
        raise ValueError('threshold must be a finite number between 0.0 and 1.0')


def _java_tokens(code: str) -> TokenSequence:
    if not isinstance(code, str):
        raise TypeError('Java source code must be provided as text.')

    tokens = tuple(
        token.value
        for token in tokenize(code)
        if getattr(token, 'value', None) is not None
    )
    if not tokens:
        raise ValueError('Cannot compare source code without Java tokens.')
    return tokens


def normalize_java(code: str) -> str:
    """Return token-level Java source with formatting and comments discarded."""
    return '\n'.join(_java_tokens(code))


def detect_plagiarism(
        source_code: str,
        candidates: Mapping[str, str],
        threshold: float = 0.85,
        language: str = 'java'
) -> List[PlagiarismMatch]:
    """
    Find candidate submissions whose surface or adversarial similarity reaches
    ``threshold``. Surface similarity is retained for compatibility; the
    adversarial score masks superficial identifier changes and adds deeper
    structural evidence.

    ``candidates`` maps a display name (usually a file path) to Java source
    text. Only matches at or above the threshold are returned, ordered from
    most to least similar. Matching block offsets are zero-based token indices
    in the normalized token sequence.
    """
    _validate_threshold(threshold)
    resolved_language = detect_language(source_code, requested=language)
    if resolved_language != 'java':
        generic_matches = []
        for candidate, candidate_code in candidates.items():
            signals = compare_token_signals(
                source_code, candidate_code, resolved_language
            )
            report = analyze_adversarial_resistance(
                source_code, candidate_code,
                deviation_threshold=1.0 - threshold,
                language=resolved_language
            )
            similarity = float(signals['surface_similarity'])
            adversarial_similarity = report.adversarial_similarity
            if max(similarity, adversarial_similarity) < threshold:
                continue
            generic_matches.append(PlagiarismMatch(
                candidate=candidate,
                similarity=similarity,
                matched_tokens=int(signals['matched_tokens']),
                source_tokens=int(signals['source_tokens']),
                candidate_tokens=int(signals['candidate_tokens']),
                matching_blocks=tuple(signals['matching_blocks']),
                is_plagiarism=True,
                adversarial_similarity=adversarial_similarity,
                residual_deviation=report.residual_deviation,
                deviation_remains=report.deviation_remains,
                resistance_value=report.resistance_value
            ))
        return sorted(generic_matches, key=lambda match: (-match.similarity, match.candidate))

    source_tokens = _java_tokens(source_code)
    matches = []

    for candidate, candidate_code in candidates.items():
        try:
            candidate_tokens = _java_tokens(candidate_code)
        except (TypeError, ValueError) as error:
            raise ValueError(f'Cannot compare candidate {candidate!r}: {error}') from error

        matcher = SequenceMatcher(None, source_tokens, candidate_tokens, autojunk=False)
        similarity = matcher.ratio()
        try:
            adversarial_report = analyze_adversarial_resistance(
                source_code,
                candidate_code,
                deviation_threshold=1.0 - threshold
            )
            adversarial_similarity = adversarial_report.adversarial_similarity
            residual_deviation = adversarial_report.residual_deviation
            deviation_remains = adversarial_report.deviation_remains
        except ValueError:
            # Preserve the original token-only behavior for malformed Java.
            adversarial_similarity = similarity
            residual_deviation = 1.0 - similarity
            deviation_remains = True

        if max(similarity, adversarial_similarity) < threshold:
            continue

        blocks = tuple(
            (block.a, block.a + block.size, block.b, block.b + block.size)
            for block in matcher.get_matching_blocks()
            if block.size
        )
        matched_tokens = sum(block[1] - block[0] for block in blocks)
        matches.append(PlagiarismMatch(
            candidate=candidate,
            similarity=similarity,
            matched_tokens=matched_tokens,
            source_tokens=len(source_tokens),
            candidate_tokens=len(candidate_tokens),
            matching_blocks=blocks,
            is_plagiarism=max(similarity, adversarial_similarity) >= threshold,
            adversarial_similarity=adversarial_similarity,
            residual_deviation=residual_deviation,
            deviation_remains=deviation_remains,
            resistance_value=adversarial_similarity - threshold
        ))

    return sorted(matches, key=lambda match: (-match.similarity, match.candidate))


def detect_plagiarism_in_files(
        source_path: FilePath,
        candidate_paths: Iterable[FilePath],
        threshold: float = 0.85,
        language: str = 'java'
) -> List[PlagiarismMatch]:
    """Detect likely copied Java submissions by comparing files on disk."""
    _validate_threshold(threshold)
    candidates = {}

    for path in candidate_paths:
        path = Path(path)
        candidates[str(path)] = path.read_text(encoding='utf-8', errors='ignore')

    source_code = Path(source_path).read_text(encoding='utf-8', errors='ignore')
    return detect_plagiarism(source_code, candidates, threshold, language)
