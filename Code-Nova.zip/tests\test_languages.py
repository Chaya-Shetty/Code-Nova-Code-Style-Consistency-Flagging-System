import unittest

from features.adversarial import analyze_adversarial_resistance
from features.languages import compare_token_signals, detect_language
from features.plagiarism import detect_plagiarism


class LanguageSupportTests(unittest.TestCase):
    def test_language_detection_supports_common_extensions_and_markers(self):
        self.assertEqual(detect_language(filename='main.py'), 'python')
        self.assertEqual(detect_language(filename='index.ts'), 'typescript')
        self.assertEqual(detect_language('func main() {}', requested='auto'), 'go')
        self.assertEqual(detect_language('const value = 1;', requested='auto'), 'javascript')

    def test_python_renaming_and_formatting_are_discounted(self):
        source = '''def total(values):
    result = 0
    for value in values:
        result += value
    return result'''
        variant = '''# reformatted
def total(items):
    result = 0
    for item in items:
        result += item
    return result'''
        report = analyze_adversarial_resistance(source, variant, language='python')

        self.assertEqual(report.language, 'python')
        self.assertGreater(report.canonical_similarity, 0.95)
        self.assertGreater(report.structural_similarity, 0.95)
        self.assertFalse(report.deviation_remains)

    def test_javascript_algorithm_change_remains_visible(self):
        source = 'function total(values) { return values.reduce((sum, value) => sum + value, 0); }'
        variant = 'function total(values) { let result = 0; for (const value of values) { result += value; } return result; }'
        report = analyze_adversarial_resistance(source, variant, language='javascript')

        self.assertEqual(report.language, 'javascript')
        self.assertGreater(report.residual_deviation, 0.15)
        self.assertTrue(report.deviation_remains)

    def test_generic_plagiarism_comparison_uses_selected_language(self):
        source = 'def add(a, b):\n    return a + b'
        candidate = 'def add(first, second):\n    return first + second'
        signals = compare_token_signals(source, candidate, 'python')
        matches = detect_plagiarism(
            source, {'renamed.py': candidate}, threshold=0.9, language='python'
        )

        self.assertEqual(signals['language'], 'python')
        self.assertEqual(len(matches), 1)
        self.assertGreaterEqual(matches[0].adversarial_similarity, 0.9)


if __name__ == '__main__':
    unittest.main()
