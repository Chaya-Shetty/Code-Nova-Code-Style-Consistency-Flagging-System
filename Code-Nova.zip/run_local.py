"""Launch the project notebook dashboard on localhost."""

import argparse
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Run the Code Genome notebook dashboard with JupyterLab.'
    )
    parser.add_argument(
        '--port', type=int, default=8888,
        help='Local port to use (default: 8888).'
    )
    parser.add_argument(
        '--no-browser', action='store_true',
        help='Do not open a browser automatically.'
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not 1 <= args.port <= 65535:
        raise SystemExit('--port must be between 1 and 65535.')

    project_root = Path(__file__).resolve().parent
    url = f'http://127.0.0.1:{args.port}/lab'
    command = [
        sys.executable,
        '-m',
        'jupyter',
        'lab',
        '--ip=127.0.0.1',
        f'--port={args.port}',
        f'--notebook-dir={project_root}',
        '--no-browser'
    ]

    print(f'Opening Code Genome dashboard at {url}')
    print('Press Ctrl+C in this terminal to stop the server.')
    if not args.no_browser:
        threading.Timer(2.0, lambda: webbrowser.open(url)).start()

    return subprocess.call(command)


if __name__ == '__main__':
    raise SystemExit(main())
