import http.client
import json
import threading
import unittest
from http.server import ThreadingHTTPServer

from webapp import CodeGenomeHandler, DEMO_PASSWORD


class WebAppTests(unittest.TestCase):
    def setUp(self):
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), CodeGenomeHandler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.host, self.port = self.server.server_address

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def request(self, method, path, payload=None, cookie=None):
        connection = http.client.HTTPConnection(self.host, self.port, timeout=5)
        headers = {}
        body = None
        if payload is not None:
            body = json.dumps(payload)
            headers['Content-Type'] = 'application/json'
        if cookie:
            headers['Cookie'] = cookie
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse()
        response_body = response.read().decode('utf-8')
        response_headers = dict(response.getheaders())
        connection.close()
        return response.status, response_headers, response_body

    def test_login_protects_dashboard_and_analysis(self):
        status, _, body = self.request('GET', '/')
        self.assertEqual(status, 200)
        self.assertIn('Code Nova Studio', body)

        status, _, _ = self.request('GET', '/api/dashboard')
        self.assertEqual(status, 401)

        status, _, _ = self.request('POST', '/api/login', {
            'email': 'alex.chen@example.com',
            'password': 'wrong'
        })
        self.assertEqual(status, 401)

        status, headers, _ = self.request('POST', '/api/login', {
            'email': 'alex.chen@example.com',
            'password': DEMO_PASSWORD
        })
        self.assertEqual(status, 200)
        cookie = headers['Set-Cookie'].split(';', 1)[0]

        status, _, body = self.request('GET', '/api/dashboard', cookie=cookie)
        self.assertEqual(status, 200)
        dashboard = json.loads(body)
        self.assertEqual(dashboard['user']['email'], 'alex.chen@example.com')
        self.assertEqual(set(dashboard['profile']['scores']), {
            'naming', 'formatting', 'comments', 'ast_structure',
            'function_patterns', 'complexity'
        })
        self.assertEqual(len(dashboard['history']), 2)
        self.assertIn('avg_cyclomatic_complexity', dashboard['history'][0]['features'])

        status, _, body = self.request('GET', '/api/history', cookie=cookie)
        self.assertEqual(status, 200)
        self.assertEqual(len(json.loads(body)['history']), 2)

        source = dashboard['demo_pair']['source']
        candidate = dashboard['demo_pair']['candidate']
        status, _, body = self.request('POST', '/api/analyze', {
            'source_code': source,
            'candidate_code': candidate,
            'threshold': 0.85
        }, cookie=cookie)
        self.assertEqual(status, 200)
        result = json.loads(body)
        self.assertFalse(result['adversarial']['deviation_remains'])
        self.assertEqual(result['plagiarism'][0]['adversarial_similarity'], 1.0)

        python_source = 'def add(a, b):\n    return a + b'
        python_candidate = 'def add(first, second):\n    return first + second'
        status, _, body = self.request('POST', '/api/analyze', {
            'source_code': python_source,
            'candidate_code': python_candidate,
            'threshold': 0.85,
            'language': 'python'
        }, cookie=cookie)
        self.assertEqual(status, 200)
        python_result = json.loads(body)
        self.assertEqual(python_result['adversarial']['language'], 'python')
        self.assertFalse(python_result['adversarial']['deviation_remains'])

        status, _, _ = self.request('POST', '/api/logout', {}, cookie=cookie)
        self.assertEqual(status, 200)
        status, _, _ = self.request('GET', '/api/dashboard', cookie=cookie)
        self.assertEqual(status, 401)


if __name__ == '__main__':
    unittest.main()
