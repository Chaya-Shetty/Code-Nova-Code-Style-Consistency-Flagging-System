from typing import Dict, List

import numpy as np
from javalang.tree import MethodDeclaration, Node

from .feature import Feature
from .utils import children, get_nodes


_DECISION_NODE_NAMES = frozenset({
    'IfStatement',
    'WhileStatement',
    'DoStatement',
    'ForStatement',
    'AssertStatement',
    'SwitchStatement',
    'CatchClause',
    'TernaryExpression'
})


def _decision_count(node: Node) -> int:
    count = 0

    for child in children(node):
        if not isinstance(child, Node):
            continue

        node_name = child.__class__.__name__
        if node_name in _DECISION_NODE_NAMES:
            count += 1
        if node_name in ('BinaryOperation', 'BinaryOperator') and getattr(child, 'operator', None) in ('&&', '||'):
            count += 1
        count += _decision_count(child)

    return count


def cyclomatic_complexity(method: MethodDeclaration) -> int:
    """Return the cyclomatic complexity of one Java method declaration."""
    return 1 + _decision_count(method)


class FunctionComplexity(Feature):
    """Calculate file-level summaries of method cyclomatic complexity."""

    @staticmethod
    def calculate(tree: Node) -> Dict:
        methods = get_nodes(tree, MethodDeclaration)
        complexities: List[int] = [
            cyclomatic_complexity(method)
            for method in methods
        ]

        if not complexities:
            return {
                'avgCyclomaticComplexity': 0.0,
                'stdDevCyclomaticComplexity': 0.0,
                'maxCyclomaticComplexity': 0.0
            }

        return {
            'avgCyclomaticComplexity': float(np.mean(complexities)),
            'stdDevCyclomaticComplexity': float(np.std(complexities)),
            'maxCyclomaticComplexity': float(max(complexities))
        }
