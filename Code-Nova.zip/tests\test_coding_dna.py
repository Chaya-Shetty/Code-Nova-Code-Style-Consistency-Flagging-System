import tempfile
import unittest
from pathlib import Path

from features.coding_dna import CodeGenome
from features.coding_dna import build_code_genome
from features.coding_dna import build_coding_dna
from features.coding_dna import compare_code_genomes
from features.coding_dna import compare_coding_dna


class CodingDNATests(unittest.TestCase):
    def test_similar_source_has_a_higher_similarity_score(self):
        author_code = '''
            public class Solution {
                public int add(int a, int b) {
                    int total = a + b;
                    if (total > 10) {
                        return total;
                    }
                    return total * 2;
                }
            }
        '''
        same_style_code = author_code.replace('total', 'sum')
        different_code = '''
            public class Other {
                int calculate(int left, int right) {
                    for (int index = 0; index < left; index++) {
                        System.out.println(right + index);
                    }
                    return 0;
                }
            }
        '''

        with tempfile.TemporaryDirectory() as directory:
            directory_path = Path(directory)
            author_path = directory_path / 'author.java'
            same_style_path = directory_path / 'same_style.java'
            different_path = directory_path / 'different.java'
            author_path.write_text(author_code, encoding='utf-8')
            same_style_path.write_text(same_style_code, encoding='utf-8')
            different_path.write_text(different_code, encoding='utf-8')

            author_dna = build_code_genome([author_path], n_jobs=1)
            same_style_dna = build_coding_dna([same_style_path], n_jobs=1)
            different_dna = build_coding_dna([different_path], n_jobs=1)
            genome_path = directory_path / 'author_genome.json'
            author_dna.save(genome_path)
            restored_dna = CodeGenome.load(genome_path)

        same_style_scores = compare_code_genomes(author_dna, same_style_dna)
        different_scores = compare_coding_dna(author_dna, different_dna)

        self.assertGreater(same_style_scores['similarity'], different_scores['similarity'])
        self.assertIn('formatting_similarity', same_style_scores)
        self.assertIn('comments_similarity', same_style_scores)
        self.assertIn('complexity_similarity', same_style_scores)
        self.assertTrue(author_dna.feature_names())
        self.assertTrue(author_dna.as_dict())
        self.assertEqual(
            set(author_dna.style_scores()),
            {
                'naming', 'formatting', 'comments', 'ast_structure',
                'function_patterns', 'complexity'
            }
        )
        self.assertEqual(restored_dna.to_dict(), author_dna.to_dict())

    def test_profile_can_be_compared_with_itself(self):
        code = 'class Example { int value() { return 42; } }'
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'Example.java'
            path.write_text(code, encoding='utf-8')
            dna = build_coding_dna([path], n_jobs=1)
            scores = compare_coding_dna(dna, dna)

        self.assertAlmostEqual(scores['similarity'], 1.0)

    def test_empty_profile_is_rejected(self):
        with self.assertRaises(ValueError):
            build_coding_dna([], n_jobs=1)


if __name__ == '__main__':
    unittest.main()
