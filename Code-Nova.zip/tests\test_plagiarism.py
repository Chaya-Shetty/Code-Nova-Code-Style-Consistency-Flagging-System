import tempfile
import unittest
from pathlib import Path

from features.plagiarism import detect_plagiarism
from features.plagiarism import detect_plagiarism_in_files
from features.plagiarism import normalize_java


class PlagiarismDetectorTests(unittest.TestCase):
    def test_reformatted_code_with_comments_is_an_exact_match(self):
        source = '''
            public class Solution {
                public int add(int a, int b) { return a + b; }
            }
        '''
        reformatted = '''// Candidate submission
public class Solution {
    public int add(int a, int b) {
        return a + b;
    }
}
'''
        with tempfile.TemporaryDirectory() as directory:
            source_path = Path(directory) / 'source.java'
            candidate_path = Path(directory) / 'reformatted.java'
            source_path.write_text(source, encoding='utf-8')
            candidate_path.write_text(reformatted, encoding='utf-8')

            matches = detect_plagiarism_in_files(
                source_path, [candidate_path], threshold=0.9
            )

        self.assertEqual(len(matches), 1)
        self.assertAlmostEqual(matches[0].similarity, 1.0)
        self.assertTrue(matches[0].is_plagiarism)
        self.assertGreater(matches[0].matched_tokens, 0)
        self.assertEqual(
            normalize_java(source).splitlines(), normalize_java(reformatted).splitlines()
        )

    def test_adversarial_similarity_survives_identifier_renaming(self):
        source = '''
            class Example {
                int add(int left, int right) { return left + right; }
            }
        '''
        renamed = '''
            class Example {
                int add(int first, int second) { return first + second; }
            }
        '''

        report = detect_plagiarism(
            source, {'renamed.java': renamed}, threshold=0.9
        )

        self.assertEqual(len(report), 1)
        self.assertGreaterEqual(report[0].adversarial_similarity, 0.9)
        self.assertFalse(report[0].deviation_remains)

    def test_unrelated_code_does_not_pass_threshold(self):
        source = 'class A { int value() { return 1; } }'
        unrelated = 'class B { void print() { System.out.println("hello"); } }'

        with tempfile.TemporaryDirectory() as directory:
            source_path = Path(directory) / 'source.java'
            candidate_path = Path(directory) / 'unrelated.java'
            source_path.write_text(source, encoding='utf-8')
            candidate_path.write_text(unrelated, encoding='utf-8')

            matches = detect_plagiarism_in_files(
                source_path, [candidate_path], threshold=0.9
            )

        self.assertEqual(matches, [])

    def test_invalid_threshold_is_rejected(self):
        with self.assertRaises(ValueError):
            detect_plagiarism_in_files('source.java', [], threshold=1.1)


if __name__ == '__main__':
    unittest.main()
