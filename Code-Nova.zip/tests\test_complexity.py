import math
import unittest

import javalang

from features.complexity import FunctionComplexity, cyclomatic_complexity
from features.lexical import NumComments
from features.utils import get_nodes
from javalang.tree import MethodDeclaration


class ComplexityTests(unittest.TestCase):
    def test_cyclomatic_complexity_counts_decision_points(self):
        tree = javalang.parse.parse('''
            class Example {
                int value(int left, int right) {
                    if ((left > 0 && right > 0) || left < 0) {
                        return left + right;
                    }
                    return 0;
                }
            }
        ''')
        method = get_nodes(tree, MethodDeclaration)[0]

        self.assertEqual(cyclomatic_complexity(method), 4)
        self.assertEqual(FunctionComplexity.calculate(tree), {
            'avgCyclomaticComplexity': 4.0,
            'stdDevCyclomaticComplexity': 0.0,
            'maxCyclomaticComplexity': 4.0
        })

    def test_comment_feature_uses_a_sentinel_instead_of_dividing_by_zero(self):
        with_comment = NumComments.calculate('// explanation\nclass Example {}')
        without_comment = NumComments.calculate('class Example {}')

        self.assertTrue(math.isfinite(with_comment['ln(numComments/length)']))
        self.assertTrue(math.isinf(without_comment['ln(numComments/length)']))


if __name__ == '__main__':
    unittest.main()
