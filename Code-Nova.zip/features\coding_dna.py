import json
from collections import defaultdict
from dataclasses import dataclass
from math import isfinite, sqrt
from pathlib import Path
from typing import Dict, Iterable, Tuple, Union

from .features import calculate_features_for_files


FilePath = Union[str, Path]
FeatureValues = Tuple[Tuple[str, float], ...]
Channel = Tuple[str, FeatureValues]
FeatureVector = Tuple[float, ...]


@dataclass(frozen=True)
class CodingDNA:
    """A normalized, multi-channel Code Genome for an author's coding style."""

    _channels: Tuple[Channel, ...]

    def feature_names(self) -> Tuple[str, ...]:
        """Return the stylometry feature names included in this profile."""
        return tuple(
            feature
            for _, values in self._channels
            for feature, _ in values
        )

    def as_dict(self) -> Dict[str, float]:
        """Return the normalized value of each feature in this profile."""
        return {
            feature: value
            for _, values in self._channels
            for feature, value in values
        }

    def to_dict(self) -> Dict[str, object]:
        """Return a JSON-serializable Code Genome profile."""
        return {
            'version': 1,
            'channels': {
                name: dict(values)
                for name, values in self._channels
            }
        }

    @classmethod
    def from_dict(cls, data: Dict[str, object]) -> 'CodingDNA':
        """Restore a previously stored Code Genome profile."""
        if not isinstance(data, dict) or data.get('version') != 1:
            raise ValueError('Unsupported Code Genome profile version.')

        raw_channels = data.get('channels')
        if not isinstance(raw_channels, dict) or not raw_channels:
            raise ValueError('Code Genome profile has no channels.')

        channels = []
        for name, raw_values in sorted(raw_channels.items()):
            if not isinstance(raw_values, dict):
                raise ValueError(f'Channel {name!r} must contain a feature mapping.')

            values = []
            for feature, raw_value in sorted(raw_values.items()):
                value = float(raw_value)
                if not isfinite(value):
                    raise ValueError(f'Feature {feature!r} has a non-finite value.')
                values.append((str(feature), value))
            channels.append((str(name), tuple(values)))

        return cls(tuple(channels))

    def save(self, path: FilePath) -> None:
        """Store this profile as a JSON document."""
        Path(path).write_text(
            json.dumps(self.to_dict(), indent=2, sort_keys=True),
            encoding='utf-8'
        )

    @classmethod
    def load(cls, path: FilePath) -> 'CodingDNA':
        """Load a profile previously written by :meth:`save`."""
        data = json.loads(Path(path).read_text(encoding='utf-8'))
        return cls.from_dict(data)

    def style_scores(self) -> Dict[str, float]:
        """Return relative signal strength for each personal-style dimension."""
        return {
            name: sum(abs(value) for _, value in values) / len(values)
            if values else 0.0
            for name, values in self._channels
        }

    def compare(self, other: 'CodingDNA') -> Dict[str, float]:
        """Compare this DNA with another profile and return similarity scores."""
        if not isinstance(other, CodingDNA):
            raise TypeError('other must be a CodingDNA instance.')

        own_channels = dict(self._channels)
        other_channels = dict(other._channels)
        shared_channels = sorted(set(own_channels).intersection(other_channels))
        if not shared_channels:
            raise ValueError('The coding DNA profiles have no comparable channels.')

        channel_scores = {
            name: _cosine_similarity(
                *_aligned_feature_vectors(own_channels[name], other_channels[name])
            )
            for name in shared_channels
        }
        scores = {
            f'{name}_similarity': score
            for name, score in channel_scores.items()
        }
        scores['similarity'] = sum(channel_scores.values()) / len(channel_scores)
        return scores


class CodeGenome(CodingDNA):
    """A named Code Genome profile with the shared CodingDNA behavior."""


def _aligned_feature_vectors(
        first: FeatureValues,
        second: FeatureValues
) -> Tuple[FeatureVector, FeatureVector]:
    """Align two channels by feature name, treating absent sparse features as zero."""
    first_by_name = dict(first)
    second_by_name = dict(second)
    all_names = sorted(set(first_by_name).union(second_by_name))
    return (
        tuple(first_by_name.get(name, 0.0) for name in all_names),
        tuple(second_by_name.get(name, 0.0) for name in all_names)
    )


def _normalize(values: Iterable[float]) -> FeatureVector:
    vector = tuple(float(value) for value in values)
    magnitude = sqrt(sum(value * value for value in vector))
    if magnitude == 0.0:
        return tuple(0.0 for _ in vector)
    return tuple(value / magnitude for value in vector)


def _cosine_similarity(first: FeatureVector, second: FeatureVector) -> float:
    if not first or not second:
        return 0.0

    numerator = sum(left * right for left, right in zip(first, second))
    denominator = sqrt(sum(value * value for value in first))
    denominator *= sqrt(sum(value * value for value in second))
    if denominator == 0.0:
        return 1.0
    return max(-1.0, min(1.0, numerator / denominator))


def _channel_for(feature: str) -> str:
    if feature == 'ln(numComments/length)':
        return 'comments'
    if 'CyclomaticComplexity' in feature:
        return 'complexity'
    if feature in ('ln(numFunctions/length)', 'avgParams', 'stdDevNumParams'):
        return 'function_patterns'
    if feature.startswith('WordUnigramTF_'):
        return 'naming'
    if feature == 'MaxDepthASTNode' or feature.startswith((
            'ASTNodeBigramsTF_', 'ASTNodeTypesTF_', 'javaKeywords_'
    )):
        return 'ast_structure'
    if feature.startswith(('ln(', 'avg', 'stdDev')):
        return 'formatting'
    return 'formatting'


def build_coding_dna(files: Iterable[FilePath], n_jobs: int = 4) -> CodingDNA:
    """
    Build a coding DNA profile from Java source files.

    Feature means are calculated per file, then the naming, formatting, comments,
    AST structure, function-pattern, and complexity channels are L2-normalized
    separately. This prevents large sparse channels from overwhelming other
    stylistic measurements when profiles are compared.
    """
    file_paths = list(files)
    if not file_paths:
        raise ValueError('At least one Java source file is required.')

    samples = calculate_features_for_files(file_paths, n_jobs=n_jobs)
    if len(samples) != len(file_paths):
        raise RuntimeError('Feature extraction returned an unexpected number of samples.')

    values_by_feature = defaultdict(list)
    for sample in samples:
        for feature, raw_value in sample.items():
            value = float(raw_value)
            values_by_feature[feature].append(value if isfinite(value) else 0.0)

    feature_names = sorted(values_by_feature)
    if not feature_names:
        raise ValueError('No coding features were found in the supplied files.')

    means_by_channel = defaultdict(list)
    names_by_channel = defaultdict(list)
    for feature in feature_names:
        mean_value = sum(values_by_feature[feature]) / len(samples)
        channel = _channel_for(feature)
        means_by_channel[channel].append(mean_value)
        names_by_channel[channel].append(feature)

    channels = tuple(
        (
            name,
            tuple(
                zip(
                    names_by_channel[name],
                    _normalize(means_by_channel[name])
                )
            )
        )
        for name in sorted(means_by_channel)
    )
    return CodingDNA(channels)


def compare_coding_dna(reference: CodingDNA, candidate: CodingDNA) -> Dict[str, float]:
    """Return an overall score and per-channel scores for two coding DNA profiles."""
    if not isinstance(reference, CodingDNA) or not isinstance(candidate, CodingDNA):
        raise TypeError('Both reference and candidate must be CodingDNA instances.')
    return reference.compare(candidate)


def build_code_genome(files: Iterable[FilePath], n_jobs: int = 4) -> CodeGenome:
    """Build a Code Genome profile from a student's historical submissions."""
    return CodeGenome(build_coding_dna(files, n_jobs=n_jobs)._channels)


def compare_code_genomes(reference: CodeGenome, candidate: CodeGenome) -> Dict[str, float]:
    """Compare two Code Genome profiles and return per-dimension scores."""
    return compare_coding_dna(reference, candidate)
