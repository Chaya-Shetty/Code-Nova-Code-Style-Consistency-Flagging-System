const state = { user: null, dashboard: null, language: localStorage.getItem('code-nova-language') || 'en', lastCompareData: null };
const languageCopy = {};
languageCopy.en = {
  language: 'Language', loginEyebrow: 'PRIVATE ANALYSIS WORKSPACE', loginTitle: 'See the code<br><em>behind</em> the code.', loginDescription: 'A calm, interactive space for exploring authorship signals, adversarial resistance, and Code Genome fingerprints.', email: 'Email address', password: 'Password', enter: 'Enter workspace', demoAccess: 'DEMO ACCESS', demoHint: 'Choose an account to fill the form. All demo accounts use the password genome123.', workspace: 'WORKSPACE', localServer: 'LOCAL SERVER', privateDefault: 'Private by default', localOnly: 'Runs on localhost', signOut: 'Sign out', nav: { overview: 'Overview', compare: 'Compare & resist', genome: 'Code Genome', method: 'How it works' }, personalEyebrow: 'PERSONAL CODE FINGERPRINT', signature: 'Your coding <em>signature.</em>', signatureDescription: 'A living profile built from the patterns you leave behind—how you name, structure, explain, and solve.', metricGenome: 'CODE GENOME', metricSamples: 'HISTORICAL CODE', metricResidual: 'ADVERSARIAL STATUS', styleDimensions: 'STYLE DIMENSIONS', signalMap: 'Personal signal map', normalized: 'NORMALIZED', quickStart: 'QUICK START', runSignal: 'Run a signal check', quickText: 'Load a sample pair or bring your own Java snippets. The workspace keeps the raw score and the deeper structural score side by side.', compareSubmissions: 'Compare submissions', analyzeOne: 'Analyze one submission', resistanceTip: 'Try the resistance test', resistanceTipText: 'Use the preloaded pair to see a superficial rename get discounted while the algorithm signal stays visible.', recentSignal: 'RECENT SIGNAL', reveal: 'What this workspace can reveal', liveApi: 'LIVE API', compareEyebrow: 'ADVERSARIAL RESISTANCE', compareTitle: 'Compare the <em>signal.</em>', compareDescription: 'Separate edits that merely change the surface from changes that alter how the program is organized.', inputPair: 'INPUT PAIR', twoSnapshots: 'Two Java snapshots', loadPair: 'Load sample pair ↗', runResistance: 'Run resistance analysis', genomeEyebrow: 'PERSONAL FINGERPRINT', genomeTitle: 'Build a <em>Code Genome.</em>', genomeDescription: 'Inspect a single submission across naming, formatting, comments, AST structure, function patterns, and complexity.', newSubmission: 'NEW SUBMISSION', javaSource: 'Java source input', generateGenome: 'Generate Code Genome', methodEyebrow: 'THE MODEL', methodTitle: 'Signals, not <em>verdicts.</em>', methodDescription: 'Code Nova Studio is an interpretable local lab. It shows the evidence so you can review it, challenge it, and use it responsibly.', ethics: 'Use this as a review signal. Code style and structure are not proof of identity, authorship, or copying. Always validate with context and human review.'
};
languageCopy.es = {
  language: 'Idioma', loginEyebrow: 'ESPACIO PRIVADO DE ANÁLISIS', loginTitle: 'Mira el código <em>detrás</em> del código.', loginDescription: 'Un espacio interactivo para explorar señales de autoría, resistencia adversarial y huellas Code Genome.', email: 'Correo electrónico', password: 'Contraseña', enter: 'Entrar al espacio', demoAccess: 'ACCESO DEMO', demoHint: 'Elige una cuenta. Todas las cuentas demo usan la contraseña genome123.', workspace: 'ESPACIO', localServer: 'SERVIDOR LOCAL', privateDefault: 'Privado por defecto', localOnly: 'Funciona en localhost', signOut: 'Cerrar sesión', nav: { overview: 'Resumen', compare: 'Comparar y resistir', genome: 'Code Genome', method: 'Cómo funciona' }, personalEyebrow: 'HUELLA DE CÓDIGO PERSONAL', signature: 'Tu <em>firma</em> de código.', signatureDescription: 'Un perfil vivo creado a partir de tus patrones: cómo nombras, estructuras, explicas y resuelves.', metricGenome: 'CODE GENOME', metricSamples: 'CÓDIGO HISTÓRICO', metricResidual: 'ESTADO ADVERSARIAL', styleDimensions: 'DIMENSIONES DE ESTILO', signalMap: 'Mapa de señales personales', normalized: 'NORMALIZADO', quickStart: 'INICIO RÁPIDO', runSignal: 'Ejecutar análisis', quickText: 'Carga un par de ejemplo o usa tus propios fragmentos Java. El espacio conserva la puntuación superficial y estructural.', compareSubmissions: 'Comparar entregas', analyzeOne: 'Analizar una entrega', resistanceTip: 'Prueba la resistencia', resistanceTipText: 'Usa el par precargado para ver cómo se descuenta un cambio superficial.', recentSignal: 'SEÑAL RECIENTE', reveal: 'Lo que puede revelar este espacio', liveApi: 'API ACTIVA', compareEyebrow: 'RESISTENCIA ADVERSARIAL', compareTitle: 'Compara la <em>señal.</em>', compareDescription: 'Separa cambios superficiales de cambios que alteran la organización del programa.', inputPair: 'PAR DE ENTRADA', twoSnapshots: 'Dos instantáneas Java', loadPair: 'Cargar ejemplo ↗', runResistance: 'Ejecutar resistencia', genomeEyebrow: 'HUELLA PERSONAL', genomeTitle: 'Construye un <em>Code Genome.</em>', genomeDescription: 'Inspecciona una entrega en nomenclatura, formato, comentarios, AST, funciones y complejidad.', newSubmission: 'NUEVA ENTREGA', javaSource: 'Código Java', generateGenome: 'Generar Code Genome', methodEyebrow: 'EL MODELO', methodTitle: 'Señales, no <em>veredictos.</em>', methodDescription: 'Code Nova Studio es un laboratorio local interpretable. Muestra la evidencia para revisarla.', ethics: 'Úsalo como señal de revisión. El estilo no demuestra identidad, autoría ni copia; siempre valida con contexto.'
};
languageCopy.fr = { ...languageCopy.en, language: 'Langue', loginEyebrow: 'ESPACE PRIVÉ D’ANALYSE', loginTitle: 'Voyez le code <em> derrière</em> le code.', loginDescription: 'Un espace interactif pour explorer les signaux d’auteurat, la résistance adversariale et les empreintes Code Genome.', email: 'Adresse e-mail', password: 'Mot de passe', enter: 'Entrer dans l’espace', demoAccess: 'ACCÈS DÉMO', demoHint: 'Choisissez un compte. Tous les comptes démo utilisent le mot de passe genome123.', workspace: 'ESPACE', localServer: 'SERVEUR LOCAL', privateDefault: 'Privé par défaut', localOnly: 'Fonctionne sur localhost', signOut: 'Se déconnecter', nav: { overview: 'Vue d’ensemble', compare: 'Comparer et résister', genome: 'Code Genome', method: 'Comment ça marche' }, personalEyebrow: 'EMPREINTE PERSONNELLE', signature: 'Votre <em>signature</em> de code.', signatureDescription: 'Un profil vivant construit à partir de vos habitudes de nommage, structure, explication et résolution.', compareEyebrow: 'RÉSISTANCE ADVERSARIALE', compareTitle: 'Comparez le <em>signal.</em>', compareDescription: 'Séparez les modifications superficielles de celles qui changent l’organisation du programme.', genomeTitle: 'Construisez un <em>Code Genome.</em>', methodEyebrow: 'LE MODÈLE', methodTitle: 'Des signaux, pas des <em>verdicts.</em>', methodDescription: 'Code Nova Studio est un laboratoire local interprétable. Il montre les preuves à vérifier.', ethics: 'Utilisez ceci comme signal de révision. Le style ne prouve ni identité, ni authorship, ni copie.' };
languageCopy.de = { ...languageCopy.en, language: 'Sprache', loginEyebrow: 'PRIVATER ANALYSEBEREICH', loginTitle: 'Sieh den Code <em>hinter</em> dem Code.', loginDescription: 'Ein ruhiger interaktiver Bereich für Autorschaftssignale, adversarielle Resistenz und Code-Genome-Profile.', email: 'E-Mail-Adresse', password: 'Passwort', enter: 'Arbeitsbereich öffnen', demoAccess: 'DEMO-ZUGANG', demoHint: 'Wähle ein Konto. Alle Demo-Konten verwenden das Passwort genome123.', workspace: 'ARBEITSBEREICH', localServer: 'LOKALER SERVER', privateDefault: 'Standardmäßig privat', localOnly: 'Läuft auf localhost', signOut: 'Abmelden', nav: { overview: 'Übersicht', compare: 'Vergleichen & widerstehen', genome: 'Code Genome', method: 'So funktioniert es' }, personalEyebrow: 'PERSÖNLICHER CODE-FINGERABDRUCK', signature: 'Deine <em>Code-Signatur.</em>', signatureDescription: 'Ein lebendiges Profil aus deinen Mustern: Benennung, Struktur, Erklärung und Lösungsstil.', compareEyebrow: 'ADVERSARIALE RESISTENZ', compareTitle: 'Vergleiche das <em>Signal.</em>', compareDescription: 'Unterscheide oberflächliche Änderungen von Änderungen an der Programmstruktur.', genomeTitle: 'Baue ein <em>Code Genome.</em>', methodEyebrow: 'DAS MODELL', methodTitle: 'Signale, keine <em>Urteile.</em>', methodDescription: 'Code Nova Studio ist ein interpretierbares lokales Labor. Es zeigt prüfbare Evidenz.', ethics: 'Nutze dies als Review-Signal. Stil beweist weder Identität noch Autorschaft oder Kopie.' };



const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

async function api(path, options = {}) {
  const response = await fetch(path, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  let data = {};
  try { data = await response.json(); } catch (_) { /* non-json response */ }
  if (!response.ok) throw new Error(data.error || 'Request failed.');
  return data;
}

function showToast(message, isError = false) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.toggle('error', isError);
  toast.classList.add('show');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('show'), 3200);
}

function setBusy(button, busy, label) {
  button.disabled = busy;
  if (busy) {
    button.dataset.previous = button.innerHTML;
    button.innerHTML = `<span>${label}</span><span>…</span>`;
  } else if (button.dataset.previous) {
    button.innerHTML = button.dataset.previous;
  }
}

function percent(value) {
  return `${Math.round(Number(value || 0) * 100)}%`;
}

function signedPercent(value) {
  const number = Number(value || 0);
  return `${number >= 0 ? '+' : ''}${Math.round(number * 100)}%`;
}

function setSection(section) {
  const titles = (languageCopy[state.language] || languageCopy.en).nav;
  $$('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.section === section));
  $$('.page-section').forEach((item) => item.classList.toggle('active-section', item.id === `${section}Section`));
  $('#pageTitle').innerHTML = `${titles[section] || titles.overview} <span id="greetingName">${state.user ? state.user.name.split(' ')[0] : 'Student'}</span>`;
}

function setText(selector, value) {
  const element = $(selector);
  if (element && value !== undefined) element.textContent = value;
}

function setHTML(selector, value) {
  const element = $(selector);
  if (element && value !== undefined) element.innerHTML = value;
}

function applyLanguage(language) {
  state.language = languageCopy[language] ? language : 'en';
  const copy = languageCopy[state.language];
  localStorage.setItem('code-nova-language', state.language);
  document.documentElement.lang = state.language;
  $('#loginLanguageSelect').value = state.language;
  $('#languageSelect').value = state.language;
  setText('#loginView .login-copy .eyebrow', copy.loginEyebrow);
  setHTML('#loginView .login-copy h1', copy.loginTitle);
  setText('#loginView .login-copy .muted', copy.loginDescription);
  setText('.workspace-label', copy.workspace);
  const navIcons = { overview: '⌂', compare: '◈', genome: '✦', method: '◎' };
  $$('.nav-item').forEach((button) => {
    const key = button.dataset.section;
    button.innerHTML = `<span class="nav-icon">${navIcons[key]}</span>${copy.nav[key]}`;
  });
  setText('#loginView .demo-hint', copy.demoHint);
  setText('#loginView .demo-divider span', copy.demoAccess);
  setText('#loginForm [data-i18n="enter"]', copy.enter);
  $$('[data-i18n-label]').forEach((element) => {
    const key = element.dataset.i18nLabel;
    const textNode = Array.from(element.childNodes).find((node) => node.nodeType === Node.TEXT_NODE);
    if (textNode && copy[key]) textNode.textContent = copy[key];
  });
  const livePill = $('.live-pill');
  if (livePill && livePill.lastChild) livePill.lastChild.textContent = ` ${copy.localServer}`;
  const footnote = $('.login-footnote');
  if (footnote && footnote.lastChild) footnote.lastChild.textContent = ` ${copy.localOnly}`;
  setText('.privacy-note strong', copy.privateDefault);
  setText('.privacy-note small', copy.localOnly);
  setText('.logout-button span', copy.signOut);
  setHTML('#overviewSection .hero-row h1', copy.signature);
  setText('#overviewSection .hero-row .eyebrow', copy.personalEyebrow);
  setText('#overviewSection .hero-description', copy.signatureDescription);
  setText('#overviewSection .metric-label:nth-of-type(1)', copy.metricGenome);
  setText('#overviewSection .metric-label:nth-of-type(2)', copy.metricSamples);
  setText('#overviewSection .metric-label:nth-of-type(3)', copy.metricResidual);
  setText('#overviewSection .genome-panel .eyebrow', copy.styleDimensions);
  setText('#overviewSection .genome-panel h3', copy.signalMap);
  setText('#overviewSection .genome-panel .panel-chip', copy.normalized);
  setText('#overviewSection .quick-panel .eyebrow', copy.quickStart);
  setText('#overviewSection .quick-panel h3', copy.runSignal);
  setText('#overviewSection .quick-panel > .muted', copy.quickText);
  setText('#overviewSection .secondary-button', copy.compareSubmissions);
  setText('#overviewSection .text-button', copy.analyzeOne);
  setText('#overviewSection .tip-box strong', copy.resistanceTip);
  setText('#overviewSection .tip-box p:last-child', copy.resistanceTipText);
  setText('#overviewSection .activity-panel .eyebrow', copy.recentSignal);
  setText('#overviewSection .activity-panel h3', copy.reveal);
  setText('#overviewSection .activity-panel .panel-chip', copy.liveApi);
  setText('#compareSection .section-heading .eyebrow', copy.compareEyebrow);
  setHTML('#compareSection .section-heading h1', copy.compareTitle);
  setText('#compareSection .section-heading .muted', copy.compareDescription);
  setText('#compareSection .editor-panel .eyebrow', copy.inputPair);
  setText('#compareSection .editor-panel h3', copy.twoSnapshots);
  setText('#loadDemoPair', copy.loadPair);
  setText('#runCompare span:first-child', copy.runResistance);
  setText('#genomeSection .section-heading .eyebrow', copy.genomeEyebrow);
  setHTML('#genomeSection .section-heading h1', copy.genomeTitle);
  setText('#genomeSection .section-heading .muted', copy.genomeDescription);
  setText('#genomeSection .editor-panel .eyebrow', copy.newSubmission);
  setText('#genomeSection .editor-panel h3', copy.javaSource);
  setText('#runGenome span:first-child', copy.generateGenome);
  setText('#methodSection .section-heading .eyebrow', copy.methodEyebrow);
  setHTML('#methodSection .section-heading h1', copy.methodTitle);
  setText('#methodSection .section-heading .muted', copy.methodDescription);
  setText('.ethics-note p', copy.ethics);
  setSection(state.dashboard ? 'overview' : 'overview');
}

function addTextElement(parent, tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  element.textContent = text;
  parent.appendChild(element);
  return element;
}

function renderScores(container, scores) {
  container.replaceChildren();
  Object.entries(scores || {}).forEach(([name, value]) => {
    const row = document.createElement('div');
    row.className = 'score-row';
    const label = document.createElement('label');
    label.textContent = name.replaceAll('_', ' ');
    const track = document.createElement('div');
    track.className = 'score-track';
    const fill = document.createElement('div');
    fill.className = 'score-fill';
    fill.style.width = `${Math.max(0, Math.min(100, Number(value) * 100))}%`;
    track.appendChild(fill);
    const output = document.createElement('output');
    output.textContent = percent(value);
    row.append(label, track, output);
    container.appendChild(row);
  });
}

function formatHistoryValue(name, value) {
  if (name === 'whitespace_ratio') return percent(value);
  if (name === 'new_line_before_open_brace' || name === 'tabs_lead_lines') return value ? 'yes' : 'no';
  return Number(value || 0).toFixed(2);
}

function renderHistory(history) {
  const container = $('#historyList');
  container.replaceChildren();
  (history || []).forEach((submission) => {
    const row = document.createElement('article');
    row.className = 'history-row';
    const meta = document.createElement('div');
    meta.className = 'history-meta';
    addTextElement(meta, 'span', 'history-date', submission.submitted_at);
    addTextElement(meta, 'strong', '', submission.filename);
    addTextElement(meta, 'small', '', `${submission.language} · ${submission.feature_count} features extracted`);
    const chips = document.createElement('div');
    chips.className = 'history-chips';
    Object.entries(submission.features || {}).forEach(([name, value]) => {
      addTextElement(chips, 'span', 'feature-chip', `${name.replaceAll('_', ' ')}: ${formatHistoryValue(name, value)}`);
    });
    row.append(meta, chips);
    container.appendChild(row);
  });
}

function renderDashboard(data) {
  state.dashboard = data;
  state.user = data.user;
  const firstName = data.user.name.split(' ')[0];
  $('#greetingName').textContent = firstName;
  $('#heroInitials').textContent = data.user.initials;
  $('#userAvatar').textContent = data.user.initials;
  $('#userAvatar').className = `avatar ${data.user.initials === 'PS' ? 'avatar-lilac' : data.user.initials === 'ML' ? 'avatar-mint' : 'avatar-coral'}`;
  $('#metricGenome').textContent = Object.keys(data.profile.scores).length;
  $('#metricSamples').textContent = data.profile.sample_count;
  $('#metricResidual').textContent = 'Run test';
  renderScores($('#profileScores'), data.profile.scores);
  renderHistory(data.history || []);
  $('#sourceCode').value = data.demo_pair.source;
  $('#candidateCode').value = data.demo_pair.candidate;
  $('#genomeCode').value = data.demo_pair.source;
  showApp();
}

function showApp() {
  $('#loginView').hidden = true;
  $('#appView').hidden = false;
  setSection('overview');
}

function showLogin() {
  state.user = null;
  state.dashboard = null;
  state.lastCompareData = null;
  $('#appView').hidden = true;
  $('#loginView').hidden = false;
}

function addResultScore(parent, label, value) {
  const card = document.createElement('div');
  card.className = 'result-score';
  addTextElement(card, 'small', '', label);
  addTextElement(card, 'strong', '', value);
  parent.appendChild(card);
}

function addDetail(parent, label, value) {
  const row = document.createElement('div');
  row.className = 'result-detail';
  addTextElement(row, 'span', '', label);
  addTextElement(row, 'b', '', value);
  parent.appendChild(row);
}

function renderCompareResult(data) {
  const report = data.adversarial;
  const match = data.plagiarism && data.plagiarism[0];
  const container = $('#compareResult');
  container.replaceChildren();
  container.classList.remove('empty-state');
  const content = document.createElement('div');
  content.className = 'result-content';
  const head = document.createElement('div');
  head.className = 'result-head';
  addTextElement(head, 'h3', '', 'Resistance report');
  const badge = addTextElement(head, 'span', `status-badge${report.deviation_remains ? ' warn' : ''}`, report.deviation_remains ? 'DEVIATION REMAINS' : 'SUPERFICIAL CHANGE DISCOUNTED');
  content.appendChild(head);
  const scoreGrid = document.createElement('div');
  scoreGrid.className = 'result-score-grid';
  addResultScore(scoreGrid, 'Surface similarity', percent(report.surface_similarity));
  addResultScore(scoreGrid, 'Canonical similarity', percent(report.canonical_similarity));
  addResultScore(scoreGrid, 'Structural similarity', percent(report.structural_similarity));
  addResultScore(scoreGrid, 'Adversarial score', percent(report.adversarial_similarity));
  addResultScore(scoreGrid, 'Resistance value', signedPercent(report.resistance_value));
  content.appendChild(scoreGrid);
  addDetail(content, 'Language', report.language_label || report.language || 'Auto');
  addDetail(content, 'Surface deviation', percent(report.surface_deviation));
  addDetail(content, 'Residual deviation', percent(report.residual_deviation));
  addDetail(content, 'Threshold-adjusted resistance', signedPercent(report.resistance_value));
  addDetail(content, 'Plagiarism match', match ? 'Candidate retained' : 'Below threshold');
  if (match) addDetail(content, 'Matched tokens', String(match.matched_tokens));
  content.appendChild(badge);
  container.appendChild(content);
}

function renderGenomeResult(data) {
  const container = $('#genomeResult');
  container.replaceChildren();
  container.classList.remove('empty-state');
  const content = document.createElement('div');
  content.className = 'result-content';
  const head = document.createElement('div');
  head.className = 'result-head';
  addTextElement(head, 'h3', '', 'Fingerprint generated');
  addTextElement(head, 'span', 'status-badge', `${data.feature_count} FEATURES`);
  content.appendChild(head);
  renderScores(content, data.scores);
  const complexity = document.createElement('div');
  complexity.className = 'result-detail';
  addTextElement(complexity, 'span', '', 'Complexity signals');
  addTextElement(complexity, 'b', '', `${data.complexity.avgCyclomaticComplexity || 0} avg · ${data.complexity.maxCyclomaticComplexity || 0} max`);
  content.appendChild(complexity);
  container.appendChild(content);
}

async function loadDashboard() {
  const data = await api('/api/dashboard');
  renderDashboard(data);
}

async function submitLogin(event) {
  event.preventDefault();
  const button = event.target.querySelector('button[type="submit"]');
  const error = $('#loginError');
  error.textContent = '';
  setBusy(button, true, 'Opening workspace');
  try {
    const data = await api('/api/login', {
      method: 'POST',
      body: JSON.stringify({ email: $('#emailInput').value, password: $('#passwordInput').value })
    });
    await loadDashboard();
    showToast(`Welcome, ${data.user.name.split(' ')[0]}.`);
  } catch (err) {
    error.textContent = err.message;
  } finally {
    setBusy(button, false);
  }
}


async function runComparison() {
  const button = $('#runCompare');
  const status = $('#compareStatus');
  status.textContent = '';
  setBusy(button, true, 'Reading structure');
  try {
    const data = await api('/api/analyze', {
      method: 'POST',
      body: JSON.stringify({
        source_code: $('#sourceCode').value,
        candidate_code: $('#candidateCode').value,
        threshold: Number($('#thresholdInput').value) / 100,
        language: $('#compareLanguage').value
      })
    });
    state.lastCompareData = data;
    renderCompareResult(data);
    $('#metricResidual').textContent = percent(data.adversarial.residual_deviation);
    status.textContent = data.adversarial.deviation_remains ? 'Meaningful structural deviation remains.' : 'Superficial changes were discounted.';
    showToast('Resistance analysis complete.');
  } catch (err) {
    status.textContent = err.message;
    showToast(err.message, true);
  } finally {
    setBusy(button, false);
  }
}

async function runGenome() {
  const button = $('#runGenome');
  const status = $('#genomeStatus');
  status.textContent = '';
  setBusy(button, true, 'Building fingerprint');
  try {
    const data = await api('/api/code-genome', {
      method: 'POST',
      body: JSON.stringify({ code: $('#genomeCode').value })
    });
    renderGenomeResult(data);
    status.textContent = 'Six style dimensions calculated.';
    showToast('Code Genome generated.');
  } catch (err) {
    status.textContent = err.message;
    showToast(err.message, true);
  } finally {
    setBusy(button, false);
  }
}

function bindFileInput(buttonSelector, inputSelector, targetSelector) {
  const button = $(buttonSelector);
  const input = $(inputSelector);
  button.addEventListener('click', () => input.click());
  input.addEventListener('change', async () => {
    const file = input.files && input.files[0];
    if (!file) return;
    $(targetSelector).value = await file.text();
    showToast(`${file.name} loaded.`);
  });
}

function updateThresholdPreview() {
  if (!state.lastCompareData) return;
  const threshold = Number($('#thresholdInput').value) / 100;
  const report = state.lastCompareData.adversarial;
  report.resistance_value = report.adversarial_similarity - threshold;
  report.deviation_remains = report.residual_deviation >= (1.0 - threshold);
  if (report.adversarial_similarity < threshold) {
    state.lastCompareData.plagiarism = [];
  }
  renderCompareResult(state.lastCompareData);
  const status = $('#compareStatus');
  status.textContent = report.deviation_remains
    ? 'Meaningful structural deviation remains at this threshold.'
    : 'Superficial changes are discounted at this threshold.';
}

function wireEvents() {
  $('#loginForm').addEventListener('submit', submitLogin);
  $('#loginLanguageSelect').addEventListener('change', (event) => applyLanguage(event.target.value));
  $('#languageSelect').addEventListener('change', (event) => applyLanguage(event.target.value));
  $('#togglePassword').addEventListener('click', () => {
    const input = $('#passwordInput');
    input.type = input.type === 'password' ? 'text' : 'password';
  });
  $$('.demo-account').forEach((button) => button.addEventListener('click', () => {
    $('#emailInput').value = button.dataset.email;
    $('#passwordInput').value = 'genome123';
    $('#emailInput').focus();
  }));
  $$('.nav-item').forEach((button) => button.addEventListener('click', () => setSection(button.dataset.section)));
  $$('[data-jump]').forEach((button) => button.addEventListener('click', () => setSection(button.dataset.jump)));
  $('#loadDemoPair').addEventListener('click', () => {
    if (!state.dashboard) return;
    $('#sourceCode').value = state.dashboard.demo_pair.source;
    $('#candidateCode').value = state.dashboard.demo_pair.candidate;
    $('#compareLanguage').value = 'java';
    showToast('Sample pair loaded.');
  });
  $('#thresholdInput').addEventListener('input', (event) => {
    $('#thresholdOutput').textContent = `${event.target.value}%`;
    updateThresholdPreview();
  });
  $('#runCompare').addEventListener('click', runComparison);
  $('#runGenome').addEventListener('click', runGenome);
  bindFileInput('#sourceFileButton', '#sourceFile', '#sourceCode');
  bindFileInput('#candidateFileButton', '#candidateFile', '#candidateCode');
  bindFileInput('#genomeFileButton', '#genomeFile', '#genomeCode');
  $('#logoutButton').addEventListener('click', async () => {
    try { await api('/api/logout', { method: 'POST', body: '{}' }); } catch (_) { /* still show login */ }
    showLogin();
    showToast('Signed out.');
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  applyLanguage(state.language);
  wireEvents();
  try {
    await api('/api/session');
    await loadDashboard();
  } catch (_) {
    showLogin();
  }
});

