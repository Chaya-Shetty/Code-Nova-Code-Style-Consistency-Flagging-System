"""Local interactive web interface for the Code Genome project."""

import argparse
import hmac
import json
import math
import mimetypes
import secrets
import tempfile
import threading
import time
import webbrowser
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Dict, Optional
from urllib.parse import urlparse

from features import analyze_adversarial_resistance
from features import build_code_genome
from features import calculate_features
from features import detect_plagiarism


ROOT = Path(__file__).resolve().parent
FRONTEND = ROOT / 'frontend'
DEFAULT_HOST = '127.0.0.1'
DEFAULT_PORT = 8765
DEMO_PASSWORD = 'genome123'
SESSION_TTL = 8 * 60 * 60

USERS: Dict[str, Dict[str, str]] = {
    'alex.chen@example.com': {
        'name': 'Alex Chen',
        'initials': 'AC',
        'role': 'Student · Java'
    },
    'priya.shah@example.com': {
        'name': 'Priya Shah',
        'initials': 'PS',
        'role': 'Student · Java'
    },
    'marcus.lee@example.com': {
        'name': 'Marcus Lee',
        'initials': 'ML',
        'role': 'Student · Java'
    }
}

DEMO_SUBMISSIONS = {
    'alex.chen@example.com': (
        '''class AlexSolution {
    public int solve(int left, int right) {
        int total = left + right;
        if (total > 10) {
            return total;
        }
        return total * 2;
    }
}''',
        '''// A renamed and reformatted version of Alex's submission.
class AlexSolution {
    public int solve(int first, int second) {
        int sum = first + second;
        if (sum > 10) { return sum; }
        return sum * 2;
    }
}'''
    ),
    'priya.shah@example.com': (
        '''class PriyaSolution {
    int calculate(int[] values) {
        int result = 0;
        for (int value : values) {
            result += value * value;
        }
        return result;
    }
}''',
        '''class PriyaSolution {
    int calculate(int[] numbers) {
        int output = 0;
        for (int number : numbers) {
            output += number * number;
        }
        return output;
    }
}'''
    ),
    'marcus.lee@example.com': (
        '''class MarcusSolution {
    boolean isValid(String value) {
        if (value == null || value.isEmpty()) {
            return false;
        }
        return value.length() >= 3 && value.length() < 32;
    }
}''',
        '''class MarcusSolution {
    boolean isValid(String text) {
        if (text == null || text.isEmpty()) { return false; }
        return text.length() >= 3 && text.length() < 32;
    }
}'''
    )
}

SESSIONS: Dict[str, Dict[str, object]] = {}
SESSION_LOCK = threading.Lock()
PROFILE_CACHE: Dict[str, Dict[str, object]] = {}
HISTORY_CACHE: Dict[str, list] = {}
HISTORY_DATES = {
    'alex.chen@example.com': ('2024-01-18', '2024-03-07'),
    'priya.shah@example.com': ('2024-02-02', '2024-04-11'),
    'marcus.lee@example.com': ('2024-02-19', '2024-05-03')
}




def _history_for(email: str) -> list:
    with SESSION_LOCK:
        cached = HISTORY_CACHE.get(email)
    if cached is not None:
        return cached

    def safe(value) -> float:
        try:
            number = float(value)
            return round(number, 4) if math.isfinite(number) else 0.0
        except (TypeError, ValueError):
            return 0.0

    history = []
    submissions = DEMO_SUBMISSIONS[email]
    with tempfile.TemporaryDirectory(prefix='submission-history-') as directory:
        for index, code in enumerate(submissions):
            path = Path(directory) / f'submission_{index}.java'
            path.write_text(code, encoding='utf-8')
            features = calculate_features(str(path))
            history.append({
                'id': f'{email}-submission-{index + 1}',
                'filename': f'{email.split("@")[0]}_submission_{index + 1}.java',
                'submitted_at': HISTORY_DATES[email][index],
                'language': 'Java',
                'feature_count': len(features),
                'features': {
                    'avg_line_length': safe(features.get('avgLineLength', 0)),
                    'whitespace_ratio': safe(features.get('whiteSpaceRatio', 0)),
                    'new_line_before_open_brace': safe(features.get('newLineBeforeOpenBrace', 0)),
                    'tabs_lead_lines': safe(features.get('tabsLeadLines', 0)),
                    'function_density': safe(features.get('ln(numFunctions/length)', 0)),
                    'comment_density': safe(features.get('ln(numComments/length)', 0)),
                    'avg_cyclomatic_complexity': safe(features.get('avgCyclomaticComplexity', 0)),
                    'max_cyclomatic_complexity': safe(features.get('maxCyclomaticComplexity', 0))
                }
            })

    with SESSION_LOCK:
        HISTORY_CACHE[email] = history
    return history


def _public_user(email: str) -> Dict[str, str]:
    user = USERS[email]
    return {'email': email, **user}


def _prune_sessions() -> None:
    now = time.time()
    expired = [
        token for token, session in SESSIONS.items()
        if session['expires'] < now
    ]
    for token in expired:
        SESSIONS.pop(token, None)


def _create_session(email: str) -> str:
    token = secrets.token_urlsafe(32)
    with SESSION_LOCK:
        _prune_sessions()
        SESSIONS[token] = {'email': email, 'expires': time.time() + SESSION_TTL}
    return token


def _session_email(cookie_header: Optional[str]) -> Optional[str]:
    if not cookie_header:
        return None

    cookie = SimpleCookie()
    try:
        cookie.load(cookie_header)
    except Exception:
        return None
    morsel = cookie.get('session_id')
    if morsel is None:
        return None

    with SESSION_LOCK:
        _prune_sessions()
        session = SESSIONS.get(morsel.value)
        if session is None:
            return None
        email = session['email']
    return email if isinstance(email, str) and email in USERS else None


def _profile_for(email: str) -> Dict[str, object]:
    with SESSION_LOCK:
        cached = PROFILE_CACHE.get(email)
    if cached is not None:
        return cached

    submissions = DEMO_SUBMISSIONS[email]
    with tempfile.TemporaryDirectory(prefix='code-genome-') as directory:
        paths = []
        for index, code in enumerate(submissions):
            path = Path(directory) / f'submission_{index}.java'
            path.write_text(code, encoding='utf-8')
            paths.append(path)
        genome = build_code_genome(paths, n_jobs=1)

    feature_values = genome.as_dict()
    complexity = {
        name: value for name, value in feature_values.items()
        if 'CyclomaticComplexity' in name
    }
    profile = {
        'scores': genome.style_scores(),
        'feature_count': len(genome.feature_names()),
        'sample_count': len(submissions),
        'complexity': complexity
    }
    with SESSION_LOCK:
        PROFILE_CACHE[email] = profile
    return profile


def _dashboard_payload(email: str) -> Dict[str, object]:
    source, candidate = DEMO_SUBMISSIONS[email]
    return {
        'user': _public_user(email),
        'profile': _profile_for(email),
        'history': _history_for(email),
        'demo_pair': {'source': source, 'candidate': candidate},
        'demo_credentials': {'password': DEMO_PASSWORD}
    }



class CodeGenomeHandler(BaseHTTPRequestHandler):
    server_version = 'CodeGenomeLocal/1.0'

    def log_message(self, format_string, *args):
        return

    def _send_json(self, status: int, payload: Dict[str, object], cookie: Optional[str] = None) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        if cookie:
            self.send_header('Set-Cookie', cookie)
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> Dict[str, object]:
        length = int(self.headers.get('Content-Length', '0'))
        if length > 2 * 1024 * 1024:
            raise ValueError('Request body is too large.')
        if length == 0:
            return {}
        try:
            value = json.loads(self.rfile.read(length).decode('utf-8'))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ValueError('Request body must be valid JSON.') from error
        if not isinstance(value, dict):
            raise ValueError('Request body must be a JSON object.')
        return value

    def _current_user(self) -> Optional[str]:
        return _session_email(self.headers.get('Cookie'))

    def _require_user(self) -> Optional[str]:
        email = self._current_user()
        if email is None:
            self._send_json(401, {'error': 'Please log in to continue.'})
        return email

    def _serve_file(self, relative_path: str) -> None:
        file_path = (FRONTEND / relative_path).resolve()
        if FRONTEND not in file_path.parents or not file_path.is_file():
            self._send_json(404, {'error': 'Not found.'})
            return

        body = file_path.read_bytes()
        content_type = mimetypes.guess_type(file_path.name)[0] or 'application/octet-stream'
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path in ('/', '/index.html'):
            self._serve_file('index.html')
            return
        if path == '/api/health':
            self._send_json(200, {'status': 'ok', 'service': 'code-genome-local'})
            return
        if path == '/api/session':
            email = self._current_user()
            if email is None:
                self._send_json(401, {'error': 'Not authenticated.'})
            else:
                self._send_json(200, {'user': _public_user(email)})
            return
        if path == '/api/dashboard':
            email = self._require_user()
            if email is not None:
                self._send_json(200, _dashboard_payload(email))
            return
        if path == '/api/history':
            email = self._require_user()
            if email is not None:
                self._send_json(200, {'history': _history_for(email)})
            return
        if path.startswith('/assets/'):
            self._serve_file(path.removeprefix('/assets/'))
            return
        self._send_json(404, {'error': 'Not found.'})


    def _logout(self) -> None:
        cookie = SimpleCookie()
        cookie.load(self.headers.get('Cookie', ''))
        morsel = cookie.get('session_id')
        if morsel is not None:
            with SESSION_LOCK:
                SESSIONS.pop(morsel.value, None)
        self._send_json(
            200,
            {'ok': True},
            'session_id=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax'
        )

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            payload = self._read_json()

            if path == '/api/login':
                email = payload.get('email', '')
                password = payload.get('password', '')
                if not isinstance(email, str) or not isinstance(password, str):
                    raise ValueError('Email and password are required.')
                email = email.strip().lower()
                if email not in USERS or not hmac.compare_digest(password, DEMO_PASSWORD):
                    self._send_json(401, {'error': 'Invalid demo email or password.'})
                    return
                token = _create_session(email)
                cookie = (
                    f'session_id={token}; Path=/; Max-Age={SESSION_TTL}; '
                    'HttpOnly; SameSite=Lax'
                )
                self._send_json(200, {'user': _public_user(email)}, cookie)
                return

            if path == '/api/logout':
                self._logout()
                return

            email = self._require_user()
            if email is None:
                return

            if path == '/api/analyze':
                source_code = payload.get('source_code', '')
                candidate_code = payload.get('candidate_code', '')
                threshold = float(payload.get('threshold', 0.85))
                language = str(payload.get('language', 'auto'))
                if not isinstance(source_code, str) or not isinstance(candidate_code, str):
                    raise ValueError('Both Java source fields are required.')
                if not source_code.strip() or not candidate_code.strip():
                    raise ValueError('Both Java source fields cannot be empty.')
                if not 0.0 <= threshold <= 1.0:
                    raise ValueError('Threshold must be between 0 and 1.')

                report = analyze_adversarial_resistance(
                    source_code,
                    candidate_code,
                    deviation_threshold=1.0 - threshold,
                    language=language
                )
                matches = detect_plagiarism(
                    source_code,
                    {'candidate.java': candidate_code},
                    threshold=threshold,
                    language=language
                )
                self._send_json(200, {
                    'adversarial': report.as_dict(),
                    'plagiarism': [match.as_dict() for match in matches]
                })
                return

            if path == '/api/code-genome':
                code = payload.get('code', '')
                if not isinstance(code, str) or not code.strip():
                    raise ValueError('Java source code is required.')
                with tempfile.TemporaryDirectory(prefix='code-genome-request-') as directory:
                    path = Path(directory) / 'submission.java'
                    path.write_text(code, encoding='utf-8')
                    genome = build_code_genome([path], n_jobs=1)
                values = genome.as_dict()
                self._send_json(200, {
                    'scores': genome.style_scores(),
                    'feature_count': len(genome.feature_names()),
                    'complexity': {
                        name: value for name, value in values.items()
                        if 'CyclomaticComplexity' in name
                    }
                })
                return

            self._send_json(404, {'error': 'Not found.'})
        except (TypeError, ValueError, UnicodeError) as error:
            self._send_json(400, {'error': str(error)})
        except Exception:
            self._send_json(500, {'error': 'The local analysis service encountered an error.'})



def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Run the Code Genome local web app.')
    parser.add_argument('--host', default=DEFAULT_HOST, help='Bind address (default: 127.0.0.1).')
    parser.add_argument('--port', type=int, default=DEFAULT_PORT, help='Port (default: 8765).')
    parser.add_argument('--no-browser', action='store_true', help='Do not open a browser.')
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not 1 <= args.port <= 65535:
        raise SystemExit('--port must be between 1 and 65535.')

    server = ThreadingHTTPServer((args.host, args.port), CodeGenomeHandler)
    server.daemon_threads = True
    url = f'http://{args.host}:{args.port}/'
    print(f'Code Nova Studio web app running at {url}')
    print('Demo accounts:')
    for email in USERS:
        print(f'  {email} / {DEMO_PASSWORD}')
    print('Press Ctrl+C to stop the server.')
    if not args.no_browser:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nStopping Code Genome web app.')
    finally:
        server.server_close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

