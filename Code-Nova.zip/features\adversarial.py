from dataclasses import dataclass
from difflib import SequenceMatcher
from math import isfinite
from pathlib import Path
from typing import Dict, Optional, Tuple, Union

import javalang
from javalang.parser import JavaParserBaseException
from javalang.tokenizer import Identifier
from javalang.tokenizer import LexerError
from javalang.tokenizer import tokenize
from javalang.tree import MethodDeclaration, Node

from .complexity import cyclomatic_complexity
from .languages import compare_token_signals, detect_language, language_label
from .utils import get_nodes


FilePath = Union[str, Path]
TokenSequence = Tuple[str, ...]


@dataclass(frozen=True)
class AdversarialResistanceReport:
    """Comparison of superficial and deeper Java code signals."""

    surface_similarity: float
    canonical_similarity: float
    structural_similarity: float
    adversarial_similarity: float
    surface_deviation: float
    residual_deviation: float
    deviation_remains: bool
    resistance_value: float = 0.0
    language: str = 'java'
    source: Optional[str] = None
    candidate: Optional[str] = None

    def as_dict(self) -> Dict[str, object]:
        """Return a JSON-serializable adversarial-resistance report."""
        return {
            'source': self.source,
            'candidate': self.candidate,
            'surface_similarity': self.surface_similarity,
            'canonical_similarity': self.canonical_similarity,
            'structural_similarity': self.structural_similarity,
            'adversarial_similarity': self.adversarial_similarity,
            'surface_deviation': self.surface_deviation,
            'residual_deviation': self.residual_deviation,
            'deviation_remains': self.deviation_remains,
            'resistance_value': self.resistance_value,
            'language': self.language,
            'language_label': language_label(self.language)
        }


def _validate_threshold(threshold: float) -> None:
    if not isfinite(threshold) or not 0.0 <= threshold <= 1.0:
        raise ValueError('threshold must be a finite number between 0.0 and 1.0')


def _tokens(code: str):
    if not isinstance(code, str):
        raise TypeError('Java source code must be provided as text.')

    tokens = tuple(token for token in tokenize(code) if token.value is not None)
    if not tokens:
        raise ValueError('Cannot compare source code without Java tokens.')
    return tokens


def _surface_similarity(source_code: str, candidate_code: str) -> float:
    """Measure raw source deviation, including formatting and comments."""
    return max(0.0, min(1.0, SequenceMatcher(
        None, source_code, candidate_code, autojunk=False
    ).ratio()))


def _canonical_tokens(code: str) -> TokenSequence:
    """Remove superficial identifier changes from the token view."""
    return tuple(
        '<ID>' if isinstance(token, Identifier) else token.value
        for token in _tokens(code)
    )


def _similarity(first: TokenSequence, second: TokenSequence) -> float:
    if not first or not second:
        return 0.0
    return max(0.0, min(1.0, SequenceMatcher(
        None, first, second, autojunk=False
    ).ratio()))


def _parse(code: str, label: str) -> Node:
    if not isinstance(code, str):
        raise TypeError('Java source code must be provided as text.')

    try:
        tree = javalang.parse.parse(code)
    except (JavaParserBaseException, LexerError) as error:
        raise ValueError(f'Unable to parse {label} Java source: {error}') from error

    if tree is None:
        raise ValueError(f'Unable to parse {label} Java source: source is empty.')
    return tree


_CONTROL_FLOW_NAMES = frozenset({
    'IfStatement', 'WhileStatement', 'DoStatement', 'ForStatement',
    'SwitchStatement', 'CatchClause', 'TernaryExpression', 'ReturnStatement',
    'ThrowStatement', 'BreakStatement', 'ContinueStatement'
})


def _parameter_count(method: MethodDeclaration) -> int:
    parameters = method.children[6] if len(method.children) > 6 else []
    return len(parameters) if isinstance(parameters, list) else 0


def _method_signature(method: MethodDeclaration) -> str:
    nodes = get_nodes(method, Node)
    counts = {}
    for node in nodes:
        name = node.__class__.__name__
        counts[name] = counts.get(name, 0) + 1
    node_summary = ','.join(f'{name}:{counts[name]}' for name in sorted(counts))
    return (
        f'params={_parameter_count(method)};nodes={len(nodes)};'
        f'complexity={cyclomatic_complexity(method)};types={node_summary}'
    )


def _ast_signature(tree: Node) -> TokenSequence:
    signature = []
    for node in get_nodes(tree, Node):
        name = node.__class__.__name__
        signature.append(name)
        if name in _CONTROL_FLOW_NAMES:
            signature.append(f'control:{name}')
        if name in ('BinaryOperation', 'BinaryOperator'):
            operator = getattr(node, 'operator', None)
            if operator is not None:
                signature.append(f'operator:{operator}')
        if name == 'MethodDeclaration':
            signature.append(f'params:{_parameter_count(node)}')
        if name == 'MethodInvocation':
            argument_lists = [
                child for child in node.children if isinstance(child, list)
            ]
            arity = len(argument_lists[0]) if argument_lists else 0
            signature.append(f'call_arity:{min(arity, 8)}')
    return tuple(signature)


def _control_signature(tree: Node) -> TokenSequence:
    return tuple(
        token for token in _ast_signature(tree)
        if token.startswith(('control:', 'operator:', 'params:', 'call_arity:'))
    )


def _function_signature(tree: Node) -> TokenSequence:
    return tuple(
        _method_signature(method)
        for method in get_nodes(tree, MethodDeclaration)
    )


def _complexity_vector(tree: Node) -> Tuple[float, ...]:
    methods = get_nodes(tree, MethodDeclaration)
    complexities = [cyclomatic_complexity(method) for method in methods]
    if not complexities:
        return (0.0, 0.0, 0.0, 0.0)

    mean = sum(complexities) / len(complexities)
    variance = sum((value - mean) ** 2 for value in complexities) / len(complexities)
    return (
        float(len(complexities)),
        mean,
        variance ** 0.5,
        float(max(complexities))
    )


def _vector_similarity(first: Tuple[float, ...], second: Tuple[float, ...]) -> float:
    numerator = sum(left * right for left, right in zip(first, second))
    first_norm = sum(value * value for value in first) ** 0.5
    second_norm = sum(value * value for value in second) ** 0.5
    if first_norm == 0.0 or second_norm == 0.0:
        return 1.0 if first_norm == second_norm else 0.0
    return max(0.0, min(1.0, numerator / (first_norm * second_norm)))



def _structural_similarity(first: Node, second: Node) -> float:
    ast_score = _similarity(_ast_signature(first), _ast_signature(second))
    control_score = _similarity(_control_signature(first), _control_signature(second))
    function_score = _similarity(_function_signature(first), _function_signature(second))
    complexity_score = _vector_similarity(
        _complexity_vector(first), _complexity_vector(second)
    )
    return (
        0.40 * ast_score
        + 0.25 * control_score
        + 0.20 * function_score
        + 0.15 * complexity_score
    )


def analyze_adversarial_resistance(
        source_code: str,
        candidate_code: str,
        deviation_threshold: float = 0.15,
        source: Optional[str] = None,
        candidate: Optional[str] = None,
        language: str = 'java'
) -> AdversarialResistanceReport:
    """Compare surface and deeper signals across supported source languages."""
    _validate_threshold(deviation_threshold)
    resolved_language = detect_language(source_code, candidate_code, language)
    surface_similarity = _surface_similarity(source_code, candidate_code)

    if resolved_language != 'java':
        signals = compare_token_signals(
            source_code, candidate_code, resolved_language
        )
        canonical_similarity = float(signals['canonical_similarity'])
        structural_similarity = float(signals['structural_similarity'])
    else:
        source_tree = _parse(source_code, 'source')
        candidate_tree = _parse(candidate_code, 'candidate')
        canonical_similarity = _similarity(
            _canonical_tokens(source_code), _canonical_tokens(candidate_code)
        )
        structural_similarity = _structural_similarity(source_tree, candidate_tree)

    adversarial_similarity = (
        0.35 * canonical_similarity + 0.65 * structural_similarity
    )
    surface_deviation = 1.0 - surface_similarity
    residual_deviation = 1.0 - adversarial_similarity
    match_threshold = 1.0 - deviation_threshold
    resistance_value = adversarial_similarity - match_threshold
    return AdversarialResistanceReport(
        surface_similarity=surface_similarity,
        canonical_similarity=canonical_similarity,
        structural_similarity=structural_similarity,
        adversarial_similarity=adversarial_similarity,
        surface_deviation=surface_deviation,
        residual_deviation=residual_deviation,
        deviation_remains=residual_deviation >= deviation_threshold,
        resistance_value=resistance_value,
        language=resolved_language,
        source=source,
        candidate=candidate
    )


def analyze_adversarial_resistance_files(
        source_path: FilePath,
        candidate_path: FilePath,
        deviation_threshold: float = 0.15,
        language: str = 'java'
) -> AdversarialResistanceReport:
    """Analyze two source files and retain their paths in the report."""
    source_path = Path(source_path)
    candidate_path = Path(candidate_path)
    return analyze_adversarial_resistance(
        source_path.read_text(encoding='utf-8', errors='ignore'),
        candidate_path.read_text(encoding='utf-8', errors='ignore'),
        deviation_threshold=deviation_threshold,
        source=str(source_path),
        candidate=str(candidate_path),
        language=language
    )

