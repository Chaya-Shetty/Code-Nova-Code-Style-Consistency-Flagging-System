"""Language detection and structural token comparison for source code."""

import io
import re
import tokenize as python_tokenize
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Dict, Iterable, Optional, Tuple

from javalang.tokenizer import Identifier, Literal
from javalang.tokenizer import tokenize as java_tokenize


LANGUAGES = {
    'java': {'label': 'Java', 'extensions': ('.java',)},
    'python': {'label': 'Python', 'extensions': ('.py', '.pyw')},
    'javascript': {'label': 'JavaScript', 'extensions': ('.js', '.jsx', '.mjs', '.cjs')},
    'typescript': {'label': 'TypeScript', 'extensions': ('.ts', '.tsx')},
    'c': {'label': 'C', 'extensions': ('.c', '.h')},
    'cpp': {'label': 'C++', 'extensions': ('.cpp', '.cc', '.cxx', '.hpp', '.hh')},
    'csharp': {'label': 'C#', 'extensions': ('.cs',)},
    'go': {'label': 'Go', 'extensions': ('.go',)},
    'rust': {'label': 'Rust', 'extensions': ('.rs',)},
    'text': {'label': 'Plain text', 'extensions': ()}
}

_ALIASES = {
    'py': 'python', 'js': 'javascript', 'jsx': 'javascript',
    'ts': 'typescript', 'tsx': 'typescript', 'c++': 'cpp',
    'c#': 'csharp', 'golang': 'go', 'rs': 'rust', 'plaintext': 'text'
}
_CONTROL_WORDS = frozenset({
    'if', 'else', 'elif', 'for', 'while', 'do', 'switch', 'case',
    'try', 'catch', 'except', 'finally', 'return', 'throw', 'match',
    'when', 'break', 'continue', 'yield', 'await', 'defer', 'go'
})
_FUNCTION_WORDS = frozenset({'def', 'function', 'fn', 'func', 'sub', 'method'})
_GENERIC_TOKEN = re.compile(
    r'(?P<comment>//[^\n]*|/\*.*?\*/)'
    r'|(?P<string>"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|`(?:\\.|[^`\\])*`)'
    r'|(?P<number>\b\d+(?:\.\d+)?\b)'
    r'|(?P<name>[A-Za-z_$][\w$]*)'
    r'|(?P<op>[^\s])', re.DOTALL
)


@dataclass(frozen=True)
class CodeToken:
    kind: str
    value: str


def normalize_language(language: Optional[str]) -> str:
    value = (language or 'auto').strip().lower()
    value = _ALIASES.get(value, value)
    return value if value in LANGUAGES or value == 'auto' else 'text'


def language_label(language: str) -> str:
    resolved = normalize_language(language)
    return LANGUAGES.get(resolved, LANGUAGES['text'])['label']


def detect_language(
        source_code: str = '',
        candidate_code: str = '',
        requested: str = 'auto',
        filename: Optional[str] = None
) -> str:
    """Resolve an explicit language or infer one from a filename/content."""
    selected = normalize_language(requested)
    if selected != 'auto':
        return selected
    if filename:
        suffix = Path(filename).suffix.lower()
        for language, info in LANGUAGES.items():
            if suffix in info['extensions']:
                return language

    text = f'{source_code}\n{candidate_code}'.lower()
    patterns = (
        ('python', ('def ', 'import ', 'print(', 'elif ', 'self.')),
        ('go', ('package ', 'func ', ':=', 'fmt.')),
        ('rust', ('fn ', 'let mut', 'println!', 'pub fn')),
        ('csharp', ('using system', 'namespace ', 'public class', 'console.')),
        ('cpp', ('#include', 'std::', 'namespace ', 'template<')),
        ('c', ('#include', 'printf(', 'struct ', 'malloc(')),
        ('typescript', ('interface ', ': string', ' as ', 'export default')),
        ('javascript', ('const ', 'let ', '=>', 'console.log', 'function ')),
        ('java', ('public class', 'public interface', 'system.out', 'package '))
    )
    for language, markers in patterns:
        if any(marker in text for marker in markers):
            return language
    return 'text'


def _generic_tokens(code: str) -> Tuple[CodeToken, ...]:
    result = []
    for match in _GENERIC_TOKEN.finditer(code):
        kind = match.lastgroup
        value = match.group(0)
        if kind == 'comment':
            continue
        if kind in ('string', 'number'):
            result.append(CodeToken('literal', value))
        elif kind == 'name':
            result.append(CodeToken('identifier', value))
        else:
            result.append(CodeToken('operator', value))
    if not result:
        raise ValueError('Cannot compare source code without tokens.')
    return tuple(result)


def _python_tokens(code: str) -> Tuple[CodeToken, ...]:
    try:
        result = []
        for token in python_tokenize.generate_tokens(io.StringIO(code).readline):
            if token.type in (python_tokenize.COMMENT, python_tokenize.ENDMARKER, python_tokenize.ERRORTOKEN, python_tokenize.NL):
                continue
            if token.type == python_tokenize.NAME:
                kind = 'keyword' if token.string in _CONTROL_WORDS or token.string in _FUNCTION_WORDS else 'identifier'
            elif token.type in (python_tokenize.NUMBER, python_tokenize.STRING):
                kind = 'literal'
            else:
                kind = 'operator'
                if token.type in (python_tokenize.INDENT, python_tokenize.DEDENT):
                    token = token._replace(string='indent' if token.type == python_tokenize.INDENT else 'dedent')
            result.append(CodeToken(kind, token.string))
        if result:
            return tuple(result)
    except (python_tokenize.TokenError, IndentationError, SyntaxError):
        pass
    return _generic_tokens(code)


def tokenize_source(code: str, language: str = 'auto') -> Tuple[CodeToken, ...]:
    """Return normalized lexical tokens for a supported source language."""
    if not isinstance(code, str):
        raise TypeError('Source code must be provided as text.')
    resolved = normalize_language(language)
    if resolved == 'java':
        result = []
        for token in java_tokenize(code):
            if getattr(token, 'value', None) is None:
                continue
            if isinstance(token, Identifier):
                kind = 'identifier'
            elif isinstance(token, Literal):
                kind = 'literal'
            else:
                kind = 'keyword' if token.__class__.__name__ == 'Keyword' else 'operator'
            result.append(CodeToken(kind, token.value))
        if result:
            return tuple(result)
        raise ValueError('Cannot compare source code without Java tokens.')
    if resolved == 'python':
        return _python_tokens(code)
    return _generic_tokens(code)



def _values(tokens: Iterable[CodeToken]) -> Tuple[str, ...]:
    return tuple(token.value for token in tokens)


def _canonical(tokens: Iterable[CodeToken]) -> Tuple[str, ...]:
    return tuple(
        '<ID>' if token.kind == 'identifier'
        else '<LITERAL>' if token.kind == 'literal'
        else token.value
        for token in tokens
    )


def _ratio(first: Tuple[str, ...], second: Tuple[str, ...]) -> float:
    if not first and not second:
        return 1.0
    if not first or not second:
        return 0.0
    return max(0.0, min(1.0, SequenceMatcher(
        None, first, second, autojunk=False
    ).ratio()))


def _vector_ratio(first: Tuple[float, ...], second: Tuple[float, ...]) -> float:
    numerator = sum(a * b for a, b in zip(first, second))
    left = sum(value * value for value in first) ** 0.5
    right = sum(value * value for value in second) ** 0.5
    if left == 0.0 or right == 0.0:
        return 1.0 if left == right else 0.0
    return max(0.0, min(1.0, numerator / (left * right)))


def _structure(tokens: Iterable[CodeToken]) -> Tuple[str, ...]:
    canonical = _canonical(tokens)
    return tuple(f'{token.kind}:{value}' for token, value in zip(tokens, canonical))


def _control_signature(tokens: Iterable[CodeToken]) -> Tuple[str, ...]:
    return tuple(
        f'{token.kind}:{token.value}'
        for token in tokens
        if token.value in _CONTROL_WORDS or token.value in {'&&', '||', 'and', 'or'}
    )


def _complexity_vector(tokens: Tuple[CodeToken, ...]) -> Tuple[float, ...]:
    values = [token.value for token in tokens]
    decisions = sum(value in _CONTROL_WORDS or value in {'&&', '||', 'and', 'or'} for value in values)
    functions = sum(value in _FUNCTION_WORDS for value in values)
    loops = sum(value in {'for', 'while', 'do'} for value in values)
    returns = sum(value == 'return' for value in values)
    return float(len(tokens)), float(decisions), float(functions), float(loops), float(returns)


def compare_token_signals(
        source_code: str,
        candidate_code: str,
        language: str = 'auto'
) -> Dict[str, object]:
    """Compare non-Java code using lexical, control-flow, and complexity signals."""
    resolved = detect_language(source_code, candidate_code, language)
    source_tokens = tokenize_source(source_code, resolved)
    candidate_tokens = tokenize_source(candidate_code, resolved)
    source_values = _values(source_tokens)
    candidate_values = _values(candidate_tokens)
    source_canonical = _canonical(source_tokens)
    candidate_canonical = _canonical(candidate_tokens)
    structure_score = _ratio(_structure(source_tokens), _structure(candidate_tokens))
    control_score = _ratio(_control_signature(source_tokens), _control_signature(candidate_tokens))
    complexity_score = _vector_ratio(
        _complexity_vector(source_tokens), _complexity_vector(candidate_tokens)
    )
    surface = _ratio(source_values, candidate_values)
    canonical = _ratio(source_canonical, candidate_canonical)
    structural = 0.55 * structure_score + 0.25 * control_score + 0.20 * complexity_score
    matcher = SequenceMatcher(None, source_values, candidate_values, autojunk=False)
    blocks = tuple(
        (block.a, block.a + block.size, block.b, block.b + block.size)
        for block in matcher.get_matching_blocks() if block.size
    )
    return {
        'language': resolved,
        'language_label': language_label(resolved),
        'surface_similarity': surface,
        'canonical_similarity': canonical,
        'structural_similarity': structural,
        'source_tokens': len(source_tokens),
        'candidate_tokens': len(candidate_tokens),
        'matched_tokens': sum(block[1] - block[0] for block in blocks),
        'matching_blocks': blocks
    }

