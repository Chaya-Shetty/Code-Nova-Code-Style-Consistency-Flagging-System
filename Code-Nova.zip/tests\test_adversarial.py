import json
import tempfile
import unittest
from pathlib import Path

from features.adversarial import analyze_adversarial_resistance
from features.adversarial import analyze_adversarial_resistance_files


class AdversarialResistanceTests(unittest.TestCase):
    source = '''
        class Example {
            int add(int left, int right) {
                int total = left + right;
                if (total > 10) {
                    return total;
                }
                return total * 2;
            }
        }
    '''

    def test_superficial_changes_leave_no_residual_deviation(self):
        reformatted = '''// reformatted submission
class Example {
    int add(int first, int second) {
        int sum = first + second;
        if (sum > 10) { return sum; }
        return sum * 2;
    }
}
'''
        report = analyze_adversarial_resistance(self.source, reformatted)

        self.assertLess(report.surface_similarity, 1.0)
        self.assertEqual(report.canonical_similarity, 1.0)
        self.assertEqual(report.structural_similarity, 1.0)
        self.assertFalse(report.deviation_remains)
        self.assertEqual(report.residual_deviation, 0.0)
        lower_ui_threshold = analyze_adversarial_resistance(
            self.source, reformatted, deviation_threshold=0.30
        )
        higher_ui_threshold = analyze_adversarial_resistance(
            self.source, reformatted, deviation_threshold=0.05
        )
        self.assertGreater(
            lower_ui_threshold.resistance_value,
            higher_ui_threshold.resistance_value
        )
        json.dumps(report.as_dict())

    def test_algorithm_change_remains_visible(self):
        changed = '''
            class Example {
                int add(int first, int second) {
                    for (int index = 0; index < first; index++) {
                        second += index;
                    }
                    return second;
                }
            }
        '''
        report = analyze_adversarial_resistance(self.source, changed)

        self.assertLess(report.structural_similarity, report.canonical_similarity)
        self.assertGreater(report.residual_deviation, 0.15)
        self.assertTrue(report.deviation_remains)

    def test_file_report_retains_source_paths(self):
        with tempfile.TemporaryDirectory() as directory:
            source_path = Path(directory) / 'source.java'
            candidate_path = Path(directory) / 'candidate.java'
            source_path.write_text(self.source, encoding='utf-8')
            candidate_path.write_text(self.source, encoding='utf-8')

            report = analyze_adversarial_resistance_files(source_path, candidate_path)

        self.assertEqual(report.source, str(source_path))
        self.assertEqual(report.candidate, str(candidate_path))
        self.assertFalse(report.deviation_remains)

    def test_invalid_java_is_reported_as_a_value_error(self):
        with self.assertRaises(ValueError):
            analyze_adversarial_resistance('class Broken {', self.source)

    def test_invalid_threshold_is_rejected(self):
        with self.assertRaises(ValueError):
            analyze_adversarial_resistance(self.source, self.source, 1.1)


if __name__ == '__main__':
    unittest.main()
