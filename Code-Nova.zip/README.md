# De-anonymizing Programmers via Code Stylometry
This project is Python implementation of [a work by Caliskan et al.](https://www.usenix.org/system/files/conference/usenixsecurity15/sec15-paper-caliskan-islam.pdf) 
for Java language.

## Installation
Clone the repo and install python packages:
```
git clone https://github.com/rebryk/code_stylometry.git
cd code_stylometry
pip install -r requirements.txt
```

The dependency set is maintained for Python 3.12.

## Run locally

Start the notebook dashboard on localhost with:

```bash
python run_local.py
```

Then open [http://127.0.0.1:8888/lab](http://127.0.0.1:8888/lab).
The server is bound to `127.0.0.1` only and Jupyter's access token remains
enabled. To choose another port or suppress the automatic browser launch:

```bash
python run_local.py --port 8890 --no-browser
```

### Interactive web app

For a browser-based interface with login and interactive analysis tools, run:

```bash
python webapp.py
```

Open **http://127.0.0.1:8765/**. The web app is local-only and uses these demo accounts:

| Email | Password |
| --- | --- |
| `alex.chen@example.com` | `genome123` |
| `priya.shah@example.com` | `genome123` |
| `marcus.lee@example.com` | `genome123` |

The web dashboard supports Code Genome scoring, Java file loading, plagiarism comparison, adversarial-resistance reports, and an interface language selector (English, Español, Français, Deutsch). It does not require a separate frontend framework or additional package.

## Usage

### Dataset
Training and validation data is represented by source code of solutions 
to programming tasks from the international programming competition Google Code Jam. 

`data/metadata.json` contains description of rounds and problems that were used to create the dataset.

If you want to download the corpus on your machine, run the following code:
```
cd data/
python crawler.py
```

It will download the solution files in `java` into `data/codejam` directory.
File paths will look like `data/codejam/<round_id>/<problem_id>/<username>.java` 

### Plagiarism detection

Compare a Java submission with other downloaded submissions. Formatting and
comments are removed before comparison, while identifiers and literals remain
part of the fingerprint. Results include a similarity score and matching token
ranges:

```python
from features import detect_plagiarism_in_files

matches = detect_plagiarism_in_files(
    'data/codejam/639102/760487/Joshik.java',
    files,
    threshold=0.90
)

for match in matches[:5]:
    print(
        match.candidate,
        f'surface={match.similarity:.1%}',
        f'adversarial={match.adversarial_similarity:.1%}',
        f'deviation_remains={match.deviation_remains}'
    )
```

Only candidates at or above the threshold are returned. A score is evidence to
review, not proof of copying; choose a threshold using labelled examples from
your own dataset.

### Code Genome (personal coding fingerprint)

A Code Genome summarizes a student's historical Java submissions across six
explicit dimensions: naming, formatting, comments, AST structure, function
patterns, and cyclomatic complexity. Build a profile, store it as JSON, and
inspect its dimension-level signal strengths:

```python
from features import build_code_genome, compare_code_genomes

author_files = [path for path in files if path.stem == 'Joshik']
genome = build_code_genome(author_files)
genome.save('data/joshik_code_genome.json')
another_genome = build_code_genome(['another_submission.java'])

print(genome.style_scores())
comparison = compare_code_genomes(genome, another_genome)
print(comparison['naming_similarity'])
```

`CodingDNA`, `build_coding_dna`, and `compare_coding_dna` remain available as
backward-compatible names. Use several representative files for a reference
profile. Code Genome scores indicate stylistic similarity; they do not
establish identity or authorship on their own.

### Adversarial resistance

Use the adversarial report when a superficial edit might make two submissions
look different. It reports raw source deviation, a canonical score with
identifier names masked, and a structural score based on AST shape, control
flow, complexity, call arity, and function organization:

```python
from features import analyze_adversarial_resistance_files

report = analyze_adversarial_resistance_files('original.java', 'edited.java')
print(report.as_dict())
print('Deviation remains:', report.deviation_remains)
```

The resistance value is the threshold-adjusted margin between the adversarial
similarity score and the selected match threshold. Moving the threshold slider
updates this value and the deviation decision live; the underlying residual
deviation remains the algorithm-level difference.

A superficial-only change should have a small `residual_deviation`. A
`deviation_remains` value of `True` means the structural difference is still
material after discounting superficial edits; it is a review signal, not proof
of plagiarism.

### Multiple programming languages

The **Compare & resist** workspace accepts and analyzes Java, Python,
JavaScript, TypeScript, C, C++, C#, Go, and Rust. Choose a language explicitly
or use `Auto detect`; Java receives AST-based analysis, while the other
languages use language-aware lexical, control-flow, operator, function, and
complexity signals.

### Features
The `features` package contains a few useful functions:
* `calculate_features_for_files(files)`
<br>This function calculates sets of features for the given source files.
<br>Usage example: `samples = calculate_features_for_files(['A.java', 'B.java'])`
* `build_dataset(samples)`
<br>Builds a pandas data frame from the given list of feature sets.
<br>Usage example: `df = build_dataset(samples)`

### Training and validation
You can open [De-anonymizing Programmers via Code Stylometry.ipynb](De-anonymizing%20Programmers%20via%20Code%20Stylometry.ipynb) to see how the methods above are used
to de-anonymize 100 users with 9 code files each.

[CatBoost](http://catboost.ai/) is used to train the model. 

## Tests
Run the automated checks with:

```bash
python -m unittest discover -s tests -v
```

## License
[MIT](LICENSE)
